---
type : game
title : Bakufuu Slash! Kizuna Arashi (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bakufuu%20Slash%21%20Kizuna%20Arashi%20%28Japan%29.7z
size : 316MB
---
