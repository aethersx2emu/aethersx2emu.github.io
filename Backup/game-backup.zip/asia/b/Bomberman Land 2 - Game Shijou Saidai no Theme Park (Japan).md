---
type : game
title : Bomberman Land 2 - Game Shijou Saidai no Theme Park (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bomberman%20Land%202%20-%20Game%20Shijou%20Saidai%20no%20Theme%20Park%20%28Japan%29.7z
size : 264MB
---
