---
type : game
title : Baldur's Gate - Dark Alliance (Japan) (Genteiban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Baldur%27s%20Gate%20-%20Dark%20Alliance%20%28Japan%29%20%28Genteiban%29.7z
size : 2.0GB
---
