---
type : game
title : Burnout 2 - Point of Impact (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Burnout%202%20-%20Point%20of%20Impact%20%28Japan%29.7z
size : 1.8GB
---
