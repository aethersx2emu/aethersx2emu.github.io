---
type : game
title : Bokujou Monogatari - Oh! Wonderful Life (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bokujou%20Monogatari%20-%20Oh%21%20Wonderful%20Life%20%28Japan%29.7z
size : 398MB
---
