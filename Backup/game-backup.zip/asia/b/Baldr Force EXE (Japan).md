---
type : game
title : Baldr Force EXE (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Baldr%20Force%20EXE%20%28Japan%29.7z
size : 1.9GB
---
