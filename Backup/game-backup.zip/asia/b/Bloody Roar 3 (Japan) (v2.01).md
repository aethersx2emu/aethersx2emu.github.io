---
type : game
title : Bloody Roar 3 (Japan) (v2.01)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bloody%20Roar%203%20%28Japan%29%20%28v2.01%29.7z
size : 577MB
---
