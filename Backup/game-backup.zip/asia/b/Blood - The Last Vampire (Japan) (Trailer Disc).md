---
type : game
title : Blood - The Last Vampire (Japan) (Trailer Disc)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Blood%20-%20The%20Last%20Vampire%20%28Japan%29%20%28Trailer%20Disc%29.7z
size : 173MB
---
