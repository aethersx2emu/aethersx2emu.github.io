---
type : game
title : Busin 0 - Wizardry Alternative Neo (Japan) (Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Busin%200%20-%20Wizardry%20Alternative%20Neo%20%28Japan%29%20%28Taikenban%29.7z
size : 383MB
---
