---
type : game
title : Busin - Wizardry Alternative (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Busin%20-%20Wizardry%20Alternative%20%28Japan%29.7z
size : 370MB
---
