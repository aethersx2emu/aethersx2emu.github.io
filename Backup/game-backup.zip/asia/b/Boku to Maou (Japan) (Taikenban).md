---
type : game
title : Boku to Maou (Japan) (Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Boku%20to%20Maou%20%28Japan%29%20%28Taikenban%29.7z
size : 347MB
---
