---
type : game
title : Beatmania II DX 16 - Empress + Premium Best (Japan) (Disc 1) (Empress Disc)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Beatmania%20II%20DX%2016%20-%20Empress%20%2B%20Premium%20Best%20%28Japan%29%20%28Disc%201%29%20%28Empress%20Disc%29.7z
size : 3.5GB
---
