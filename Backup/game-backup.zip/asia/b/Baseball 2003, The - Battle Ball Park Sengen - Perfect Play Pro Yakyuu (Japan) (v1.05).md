---
type : game
title : Baseball 2003, The - Battle Ball Park Sengen - Perfect Play Pro Yakyuu (Japan) (v1.05)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Baseball%202003%2C%20The%20-%20Battle%20Ball%20Park%20Sengen%20-%20Perfect%20Play%20Pro%20Yakyuu%20%28Japan%29%20%28v1.05%29.7z
size : 1.6GB
---
