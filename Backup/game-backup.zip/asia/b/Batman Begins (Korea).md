---
type : game
title : Batman Begins (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Batman%20Begins%20%28Korea%29.7z
size : 1.5GB
---
