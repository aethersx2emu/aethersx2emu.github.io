---
type : game
title : Burnout 3 - Takedown (Japan) (Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Burnout%203%20-%20Takedown%20%28Japan%29%20%28Taikenban%29.7z
size : 91MB
---
