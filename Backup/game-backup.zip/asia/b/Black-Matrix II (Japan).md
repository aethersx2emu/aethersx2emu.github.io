---
type : game
title : Black-Matrix II (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Black-Matrix%20II%20%28Japan%29.7z
size : 133MB
---
