---
type : game
title : Buzz! The Maha Quiz (India)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Buzz%21%20The%20Maha%20Quiz%20%28India%29.7z
size : 1.6GB
---
