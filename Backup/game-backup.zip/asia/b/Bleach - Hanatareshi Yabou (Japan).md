---
type : game
title : Bleach - Hanatareshi Yabou (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bleach%20-%20Hanatareshi%20Yabou%20%28Japan%29.7z
size : 1.2GB
---
