---
type : game
title : Bass Landing 3 (Japan) (Sammy Best)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bass%20Landing%203%20%28Japan%29%20%28Sammy%20Best%29.7z
size : 361MB
---
