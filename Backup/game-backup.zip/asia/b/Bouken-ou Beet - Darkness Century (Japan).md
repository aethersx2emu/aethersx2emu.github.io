---
type : game
title : Bouken-ou Beet - Darkness Century (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bouken-ou%20Beet%20-%20Darkness%20Century%20%28Japan%29.7z
size : 839MB
---
