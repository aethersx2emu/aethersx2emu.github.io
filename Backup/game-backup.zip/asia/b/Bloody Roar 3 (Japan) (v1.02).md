---
type : game
title : Bloody Roar 3 (Japan) (v1.02)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bloody%20Roar%203%20%28Japan%29%20%28v1.02%29.7z
size : 573MB
---
