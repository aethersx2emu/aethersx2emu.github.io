---
type : game
title : Bakumatsu Renka - Karyuu Kenshiden (Japan) (Genteiban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bakumatsu%20Renka%20-%20Karyuu%20Kenshiden%20%28Japan%29%20%28Genteiban%29.7z
size : 1.8GB
---
