---
type : game
title : Boboboubo Boubobo - Hajike Matsuri (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Boboboubo%20Boubobo%20-%20Hajike%20Matsuri%20%28Japan%29.7z
size : 789MB
---
