---
type : game
title : Black (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Black%20%28Japan%29.7z
size : 1.0GB
---
