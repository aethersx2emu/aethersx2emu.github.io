---
type : game
title : Baldr Bullet Equilibrium (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Baldr%20Bullet%20Equilibrium%20%28Japan%29.7z
size : 1.1GB
---
