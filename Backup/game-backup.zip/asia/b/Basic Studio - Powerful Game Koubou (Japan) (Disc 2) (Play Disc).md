---
type : game
title : Basic Studio - Powerful Game Koubou (Japan) (Disc 2) (Play Disc)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Basic%20Studio%20-%20Powerful%20Game%20Koubou%20%28Japan%29%20%28Disc%202%29%20%28Play%20Disc%29.7z
size : 7MB
---
