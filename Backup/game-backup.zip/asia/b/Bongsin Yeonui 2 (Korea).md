---
type : game
title : Bongsin Yeonui 2 (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bongsin%20Yeonui%202%20%28Korea%29.7z
size : 3.6GB
---
