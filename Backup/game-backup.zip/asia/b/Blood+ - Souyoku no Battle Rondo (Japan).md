---
type : game
title : Blood+ - Souyoku no Battle Rondo (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Blood%2B%20-%20Souyoku%20no%20Battle%20Rondo%20%28Japan%29.7z
size : 447MB
---
