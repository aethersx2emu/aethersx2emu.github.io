---
type : game
title : Bansuk Yeongung vs 3D (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bansuk%20Yeongung%20vs%203D%20%28Korea%29.7z
size : 1.3GB
---
