---
type : game
title : Berserk - Millennium Falcon-hen - Seima Senki no Shou (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Berserk%20-%20Millennium%20Falcon-hen%20-%20Seima%20Senki%20no%20Shou%20%28Japan%29.7z
size : 3.4GB
---
