---
type : game
title : Baldur's Gate - Dark Alliance II (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Baldur%27s%20Gate%20-%20Dark%20Alliance%20II%20%28Japan%29.7z
size : 1.9GB
---
