---
type : game
title : Bakusou Convoy Densetsu - Otoko Hanamichi America Roman (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bakusou%20Convoy%20Densetsu%20-%20Otoko%20Hanamichi%20America%20Roman%20%28Japan%29.7z
size : 383MB
---
