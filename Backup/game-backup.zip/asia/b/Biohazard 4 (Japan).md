---
type : game
title : Biohazard 4 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Biohazard%204%20%28Japan%29.7z
size : 3.0GB
---
