---
type : game
title : Bikkuri Mouse (Japan) (Tentou Shiyuudai-you Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bikkuri%20Mouse%20%28Japan%29%20%28Tentou%20Shiyuudai-you%20Taikenban%29.7z
size : 121MB
---
