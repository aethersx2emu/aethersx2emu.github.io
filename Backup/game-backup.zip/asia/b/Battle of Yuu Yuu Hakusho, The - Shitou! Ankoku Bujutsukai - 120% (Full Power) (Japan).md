---
type : game
title : Battle of Yuu Yuu Hakusho, The - Shitou! Ankoku Bujutsukai - 120% (Full Power) (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Battle%20of%20Yuu%20Yuu%20Hakusho%2C%20The%20-%20Shitou%21%20Ankoku%20Bujutsukai%20-%20120%25%20%28Full%20Power%29%20%28Japan%29.7z
size : 1.9GB
---
