---
type : game
title : Blood+ - One Night Kiss (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Blood%2B%20-%20One%20Night%20Kiss%20%28Japan%29.7z
size : 1.4GB
---
