---
type : game
title : Boukoku no Aegis 2035 - Warship Gunner (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Boukoku%20no%20Aegis%202035%20-%20Warship%20Gunner%20%28Japan%29.7z
size : 818MB
---
