---
type : game
title : Bakusou Dekotora Densetsu - Otoko Hanamichi Yume Roman (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bakusou%20Dekotora%20Densetsu%20-%20Otoko%20Hanamichi%20Yume%20Roman%20%28Japan%29.7z
size : 1.8GB
---
