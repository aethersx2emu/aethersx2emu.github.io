---
type : game
title : Bomberman Kart DX (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bomberman%20Kart%20DX%20%28Japan%29.7z
size : 137MB
---
