---
type : game
title : Blood - The Last Vampire - Joukan (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Blood%20-%20The%20Last%20Vampire%20-%20Joukan%20%28Japan%29.7z
size : 2.0GB
---
