---
type : game
title : Black Cat - Kikai-jikake no Tenshi (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Black%20Cat%20-%20Kikai-jikake%20no%20Tenshi%20%28Japan%29.7z
size : 631MB
---
