---
type : game
title : BuileBaku (Japan) (Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/BuileBaku%20%28Japan%29%20%28Taikenban%29.7z
size : 303MB
---
