---
type : game
title : Bujingai (Japan, Asia)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bujingai%20%28Japan%2C%20Asia%29.7z
size : 4.0GB
---
