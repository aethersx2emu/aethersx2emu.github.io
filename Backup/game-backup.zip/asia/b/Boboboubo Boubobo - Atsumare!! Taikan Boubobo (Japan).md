---
type : game
title : Boboboubo Boubobo - Atsumare!! Taikan Boubobo (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Boboboubo%20Boubobo%20-%20Atsumare%21%21%20Taikan%20Boubobo%20%28Japan%29.7z
size : 73MB
---
