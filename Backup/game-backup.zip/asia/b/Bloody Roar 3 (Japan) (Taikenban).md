---
type : game
title : Bloody Roar 3 (Japan) (Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bloody%20Roar%203%20%28Japan%29%20%28Taikenban%29.7z
size : 317MB
---
