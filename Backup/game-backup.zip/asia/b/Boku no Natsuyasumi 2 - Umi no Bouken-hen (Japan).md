---
type : game
title : Boku no Natsuyasumi 2 - Umi no Bouken-hen (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Boku%20no%20Natsuyasumi%202%20-%20Umi%20no%20Bouken-hen%20%28Japan%29.7z
size : 1.1GB
---
