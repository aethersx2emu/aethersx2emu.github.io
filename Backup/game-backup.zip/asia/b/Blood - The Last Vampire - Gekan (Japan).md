---
type : game
title : Blood - The Last Vampire - Gekan (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Blood%20-%20The%20Last%20Vampire%20-%20Gekan%20%28Japan%29.7z
size : 2.1GB
---
