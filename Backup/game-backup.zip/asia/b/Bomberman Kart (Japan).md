---
type : game
title : Bomberman Kart (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bomberman%20Kart%20%28Japan%29.7z
size : 176MB
---
