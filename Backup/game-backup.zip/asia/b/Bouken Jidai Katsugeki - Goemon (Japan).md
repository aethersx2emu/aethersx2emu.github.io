---
type : game
title : Bouken Jidai Katsugeki - Goemon (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bouken%20Jidai%20Katsugeki%20-%20Goemon%20%28Japan%29.7z
size : 348MB
---
