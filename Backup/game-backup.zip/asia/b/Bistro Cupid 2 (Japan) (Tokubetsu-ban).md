---
type : game
title : Bistro Cupid 2 (Japan) (Tokubetsu-ban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Bistro%20Cupid%202%20%28Japan%29%20%28Tokubetsu-ban%29.7z
size : 1.4GB
---
