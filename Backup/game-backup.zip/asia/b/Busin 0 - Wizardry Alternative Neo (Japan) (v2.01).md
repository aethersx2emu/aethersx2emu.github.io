---
type : game
title : Busin 0 - Wizardry Alternative Neo (Japan) (v2.01)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Busin%200%20-%20Wizardry%20Alternative%20Neo%20%28Japan%29%20%28v2.01%29.7z
size : 383MB
---
