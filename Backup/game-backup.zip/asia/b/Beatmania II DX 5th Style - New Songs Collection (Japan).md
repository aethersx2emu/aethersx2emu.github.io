---
type : game
title : Beatmania II DX 5th Style - New Songs Collection (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Beatmania%20II%20DX%205th%20Style%20-%20New%20Songs%20Collection%20%28Japan%29.7z
size : 3.0GB
---
