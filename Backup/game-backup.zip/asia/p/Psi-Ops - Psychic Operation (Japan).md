---
type : game
title : Psi-Ops - Psychic Operation (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Psi-Ops%20-%20Psychic%20Operation%20%28Japan%29.7z
size : 2.5GB
---
