---
type : game
title : Panel Quiz Attack 25 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Panel%20Quiz%20Attack%2025%20%28Japan%29.7z
size : 1.7GB
---
