---
type : game
title : Pro Yakyuu Team o Tsukurou! 3 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pro%20Yakyuu%20Team%20o%20Tsukurou%21%203%20%28Japan%29.7z
size : 1.6GB
---
