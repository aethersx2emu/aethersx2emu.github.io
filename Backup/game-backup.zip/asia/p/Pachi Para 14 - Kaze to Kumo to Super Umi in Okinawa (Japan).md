---
type : game
title : Pachi Para 14 - Kaze to Kumo to Super Umi in Okinawa (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachi%20Para%2014%20-%20Kaze%20to%20Kumo%20to%20Super%20Umi%20in%20Okinawa%20%28Japan%29.7z
size : 2.2GB
---
