---
type : game
title : Puyo Puyo! (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Puyo%20Puyo%21%20%28Japan%29.7z
size : 358MB
---
