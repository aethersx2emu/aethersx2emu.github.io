---
type : game
title : Play-Pre Plus 004 - 2000 June (Japan) (Disc 2)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Play-Pre%20Plus%20004%20-%202000%20June%20%28Japan%29%20%28Disc%202%29.7z
size : 493MB
---
