---
type : game
title : Play-Pre 2 Volume 12 - 2004 December - PSP Movie Collection and CM Collection (Japan)
genre : 
region : asia
format : iso
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Play-Pre%202%20Volume%2012%20-%202004%20December%20-%20PSP%20Movie%20Collection%20%26%20CM%20Collection%20%28Japan%29.7z
size : 3.7GB
---
