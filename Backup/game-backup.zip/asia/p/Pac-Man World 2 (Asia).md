---
type : game
title : Pac-Man World 2 (Asia)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pac-Man%20World%202%20%28Asia%29.7z
size : 788MB
---
