---
type : game
title : Pilot ni Narou! 2 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pilot%20ni%20Narou%21%202%20%28Japan%29.7z
size : 235MB
---
