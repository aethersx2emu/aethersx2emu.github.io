---
type : game
title : Princess Maker 4 (Japan) (Collector's Edition)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Princess%20Maker%204%20%28Japan%29%20%28Collector%27s%20Edition%29.7z
size : 680MB
---
