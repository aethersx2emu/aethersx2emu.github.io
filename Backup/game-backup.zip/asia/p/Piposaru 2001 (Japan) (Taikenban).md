---
type : game
title : Piposaru 2001 (Japan) (Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Piposaru%202001%20%28Japan%29%20%28Taikenban%29.7z
size : 214MB
---
