---
type : game
title : Phantom Brave - 2-shuume Hajimemashita. (Japan) (PlayStation 2 the Best) (v2.00)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Phantom%20Brave%20-%202-shuume%20Hajimemashita.%20%28Japan%29%20%28PlayStation%202%20the%20Best%29%20%28v2.00%29.7z
size : 394MB
---
