---
type : game
title : Pandora - Kimi no Namae o Boku wa Shiru (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pandora%20-%20Kimi%20no%20Namae%20o%20Boku%20wa%20Shiru%20%28Japan%29.7z
size : 1.4GB
---
