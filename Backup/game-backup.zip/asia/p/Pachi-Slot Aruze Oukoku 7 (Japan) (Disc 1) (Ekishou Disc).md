---
type : game
title : Pachi-Slot Aruze Oukoku 7 (Japan) (Disc 1) (Ekishou Disc)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachi-Slot%20Aruze%20Oukoku%207%20%28Japan%29%20%28Disc%201%29%20%28Ekishou%20Disc%29.7z
size : 244MB
---
