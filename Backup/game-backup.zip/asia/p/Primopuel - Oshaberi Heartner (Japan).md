---
type : game
title : Primopuel - Oshaberi Heartner (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Primopuel%20-%20Oshaberi%20Heartner%20%28Japan%29.7z
size : 67MB
---
