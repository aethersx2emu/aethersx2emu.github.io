---
type : game
title : Psyvariar - Complete Edition (Japan) (Special Capture Box)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Psyvariar%20-%20Complete%20Edition%20%28Japan%29%20%28Special%20Capture%20Box%29.7z
size : 525MB
---
