---
type : game
title : Princess Maker (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Princess%20Maker%20%28Korea%29.7z
size : 236MB
---
