---
type : game
title : Puyo Puyo Fever 2 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Puyo%20Puyo%20Fever%202%20%28Japan%29.7z
size : 324MB
---
