---
type : game
title : Persona 3 FES (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Persona%203%20FES%20%28Japan%29.7z
size : 2.5GB
---
