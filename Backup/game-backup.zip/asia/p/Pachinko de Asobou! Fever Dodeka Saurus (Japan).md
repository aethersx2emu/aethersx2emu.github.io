---
type : game
title : Pachinko de Asobou! Fever Dodeka Saurus (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachinko%20de%20Asobou%21%20Fever%20Dodeka%20Saurus%20%28Japan%29.7z
size : 550MB
---
