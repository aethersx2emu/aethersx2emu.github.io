---
type : game
title : Play-Pre 2 Volume 12 - 2004 December (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Play-Pre%202%20Volume%2012%20-%202004%20December%20%28Japan%29.7z
size : 2.5GB
---
