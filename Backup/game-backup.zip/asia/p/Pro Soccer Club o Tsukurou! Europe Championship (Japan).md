---
type : game
title : Pro Soccer Club o Tsukurou! Europe Championship (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pro%20Soccer%20Club%20o%20Tsukurou%21%20Europe%20Championship%20%28Japan%29.7z
size : 2.1GB
---
