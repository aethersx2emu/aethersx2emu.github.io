---
type : game
title : Project FIFA World Cup - Sorenara Kimi ga Daihyou Kantoku (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Project%20FIFA%20World%20Cup%20-%20Sorenara%20Kimi%20ga%20Daihyou%20Kantoku%20%28Japan%29.7z
size : 900MB
---
