---
type : game
title : Pachi Para 13 - Super Umi to Pachi Pro Fuuunroku (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachi%20Para%2013%20-%20Super%20Umi%20to%20Pachi%20Pro%20Fuuunroku%20%28Japan%29.7z
size : 1.8GB
---
