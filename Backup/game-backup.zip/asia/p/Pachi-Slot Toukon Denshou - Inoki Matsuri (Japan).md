---
type : game
title : Pachi-Slot Toukon Denshou - Inoki Matsuri (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachi-Slot%20Toukon%20Denshou%20-%20Inoki%20Matsuri%20%28Japan%29.7z
size : 153MB
---
