---
type : game
title : Pachi-Slot Aruze Oukoku 6 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachi-Slot%20Aruze%20Oukoku%206%20%28Japan%29.7z
size : 391MB
---
