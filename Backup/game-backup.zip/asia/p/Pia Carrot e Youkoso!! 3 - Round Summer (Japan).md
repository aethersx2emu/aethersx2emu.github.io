---
type : game
title : Pia Carrot e Youkoso!! 3 - Round Summer (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pia%20Carrot%20e%20Youkoso%21%21%203%20-%20Round%20Summer%20%28Japan%29.7z
size : 1.4GB
---
