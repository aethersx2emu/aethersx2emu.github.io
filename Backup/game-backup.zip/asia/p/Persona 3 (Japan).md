---
type : game
title : Persona 3 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Persona%203%20%28Japan%29.7z
size : 1.9GB
---
