---
type : game
title : Pachi-Slot Kanzen Kouryaku - Slot Genjin, Onihama Bakusou Gurentai - Gekitou-hen (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachi-Slot%20Kanzen%20Kouryaku%20-%20Slot%20Genjin%2C%20Onihama%20Bakusou%20Gurentai%20-%20Gekitou-hen%20%28Japan%29.7z
size : 392MB
---
