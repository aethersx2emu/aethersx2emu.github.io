---
type : game
title : Pachitte Chonmage Tatsujin 12 - Pachinko Ultraman (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachitte%20Chonmage%20Tatsujin%2012%20-%20Pachinko%20Ultraman%20%28Japan%29.7z
size : 447MB
---
