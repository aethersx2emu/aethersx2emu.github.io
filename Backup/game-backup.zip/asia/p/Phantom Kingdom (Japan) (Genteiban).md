---
type : game
title : Phantom Kingdom (Japan) (Genteiban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Phantom%20Kingdom%20%28Japan%29%20%28Genteiban%29.7z
size : 406MB
---
