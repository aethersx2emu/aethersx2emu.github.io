---
type : game
title : Patissier na Nyanko - Hatsukoi wa Ichigo Aji (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Patissier%20na%20Nyanko%20-%20Hatsukoi%20wa%20Ichigo%20Aji%20%28Japan%29.7z
size : 1.0GB
---
