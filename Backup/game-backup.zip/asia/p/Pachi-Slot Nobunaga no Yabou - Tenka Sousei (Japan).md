---
type : game
title : Pachi-Slot Nobunaga no Yabou - Tenka Sousei (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachi-Slot%20Nobunaga%20no%20Yabou%20-%20Tenka%20Sousei%20%28Japan%29.7z
size : 107MB
---
