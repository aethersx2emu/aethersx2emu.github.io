---
type : game
title : PS2 Linux Beta Release 1 (Japan) (En,Ja)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/PS2%20Linux%20Beta%20Release%201%20%28Japan%29%20%28En%2CJa%29.7z
size : 1.1GB
---
