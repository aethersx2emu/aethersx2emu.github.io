---
type : game
title : Pro Yakyuu - Netsu Star 2006 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pro%20Yakyuu%20-%20Netsu%20Star%202006%20%28Japan%29.7z
size : 1.2GB
---
