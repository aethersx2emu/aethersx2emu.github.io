---
type : game
title : PlayStation Index (DVD-ROM-ban) - PlayStation 2 Official Soft Catalog 2002 April (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/PlayStation%20Index%20%28DVD-ROM-ban%29%20-%20PlayStation%202%20Official%20Soft%20Catalog%202002%20April%20%28Japan%29.7z
size : 3.0GB
---
