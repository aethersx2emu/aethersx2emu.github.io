---
type : game
title : Peter Jackson's King Kong - The Official Game of the Movie (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Peter%20Jackson%27s%20King%20Kong%20-%20The%20Official%20Game%20of%20the%20Movie%20%28Japan%29.7z
size : 830MB
---
