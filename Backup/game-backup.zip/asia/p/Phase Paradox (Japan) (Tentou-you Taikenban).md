---
type : game
title : Phase Paradox (Japan) (Tentou-you Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Phase%20Paradox%20%28Japan%29%20%28Tentou-you%20Taikenban%29.7z
size : 413MB
---
