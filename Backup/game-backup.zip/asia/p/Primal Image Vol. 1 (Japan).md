---
type : game
title : Primal Image Vol. 1 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Primal%20Image%20Vol.%201%20%28Japan%29.7z
size : 170MB
---
