---
type : game
title : Puyo Puyo Fever (Japan) (En,Ja,Fr,De,Es,It)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Puyo%20Puyo%20Fever%20%28Japan%29%20%28En%2CJa%2CFr%2CDe%2CEs%2CIt%29.7z
size : 263MB
---
