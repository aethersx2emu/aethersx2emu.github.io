---
type : game
title : Pachi Para 12 - Ooumi to Natsu no Omoide (Japan) (v1.02)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachi%20Para%2012%20-%20Ooumi%20to%20Natsu%20no%20Omoide%20%28Japan%29%20%28v1.02%29.7z
size : 929MB
---
