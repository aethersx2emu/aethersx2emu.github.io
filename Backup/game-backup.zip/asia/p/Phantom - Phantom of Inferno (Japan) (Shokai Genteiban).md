---
type : game
title : Phantom - Phantom of Inferno (Japan) (Shokai Genteiban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Phantom%20-%20Phantom%20of%20Inferno%20%28Japan%29%20%28Shokai%20Genteiban%29.7z
size : 2.9GB
---
