---
type : game
title : Pachitte Chonmage Tatsujin 13 - Pachinko Hissatsu Shigotonin III (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachitte%20Chonmage%20Tatsujin%2013%20-%20Pachinko%20Hissatsu%20Shigotonin%20III%20%28Japan%29.7z
size : 526MB
---
