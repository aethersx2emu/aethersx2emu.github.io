---
type : game
title : PoPoLoCrois - Hajimari no Bouken (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/PoPoLoCrois%20-%20Hajimari%20no%20Bouken%20%28Japan%29.7z
size : 1.7GB
---
