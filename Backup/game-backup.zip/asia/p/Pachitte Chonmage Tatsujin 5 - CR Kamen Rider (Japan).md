---
type : game
title : Pachitte Chonmage Tatsujin 5 - CR Kamen Rider (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachitte%20Chonmage%20Tatsujin%205%20-%20CR%20Kamen%20Rider%20%28Japan%29.7z
size : 525MB
---
