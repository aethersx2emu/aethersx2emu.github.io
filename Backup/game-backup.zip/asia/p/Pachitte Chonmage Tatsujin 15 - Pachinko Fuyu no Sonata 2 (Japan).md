---
type : game
title : Pachitte Chonmage Tatsujin 15 - Pachinko Fuyu no Sonata 2 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachitte%20Chonmage%20Tatsujin%2015%20-%20Pachinko%20Fuyu%20no%20Sonata%202%20%28Japan%29.7z
size : 1.3GB
---
