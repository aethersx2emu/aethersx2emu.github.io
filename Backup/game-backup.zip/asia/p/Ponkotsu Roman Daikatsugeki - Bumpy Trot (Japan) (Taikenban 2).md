---
type : game
title : Ponkotsu Roman Daikatsugeki - Bumpy Trot (Japan) (Taikenban 2)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Ponkotsu%20Roman%20Daikatsugeki%20-%20Bumpy%20Trot%20%28Japan%29%20%28Taikenban%202%29.7z
size : 428MB
---
