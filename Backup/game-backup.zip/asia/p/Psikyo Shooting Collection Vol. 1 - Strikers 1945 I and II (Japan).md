---
type : game
title : Psikyo Shooting Collection Vol. 1 - Strikers 1945 I and II (Japan)
genre : 
region : asia
format : iso
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Psikyo%20Shooting%20Collection%20Vol.%201%20-%20Strikers%201945%20I%20%26%20II%20%28Japan%29.7z
size : 53MB
---
