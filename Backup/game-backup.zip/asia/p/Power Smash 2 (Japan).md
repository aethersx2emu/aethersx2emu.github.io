---
type : game
title : Power Smash 2 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Power%20Smash%202%20%28Japan%29.7z
size : 178MB
---
