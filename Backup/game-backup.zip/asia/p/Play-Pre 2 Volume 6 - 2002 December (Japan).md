---
type : game
title : Play-Pre 2 Volume 6 - 2002 December (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Play-Pre%202%20Volume%206%20-%202002%20December%20%28Japan%29.7z
size : 2.6GB
---
