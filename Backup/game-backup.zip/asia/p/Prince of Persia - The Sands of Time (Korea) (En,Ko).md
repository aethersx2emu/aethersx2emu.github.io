---
type : game
title : Prince of Persia - The Sands of Time (Korea) (En,Ko)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Prince%20of%20Persia%20-%20The%20Sands%20of%20Time%20%28Korea%29%20%28En%2CKo%29.7z
size : 1.7GB
---
