---
type : game
title : PaRappa the Rapper 2 (Japan) (Tentou-you Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/PaRappa%20the%20Rapper%202%20%28Japan%29%20%28Tentou-you%20Taikenban%29.7z
size : 208MB
---
