---
type : game
title : Phase Paradox (Japan) (Taikenban 2)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Phase%20Paradox%20%28Japan%29%20%28Taikenban%202%29.7z
size : 399MB
---
