---
type : game
title : Persona 4 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Persona%204%20%28Japan%29.7z
size : 2.0GB
---
