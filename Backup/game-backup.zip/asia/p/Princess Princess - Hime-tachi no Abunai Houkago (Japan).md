---
type : game
title : Princess Princess - Hime-tachi no Abunai Houkago (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Princess%20Princess%20-%20Hime-tachi%20no%20Abunai%20Houkago%20%28Japan%29.7z
size : 599MB
---
