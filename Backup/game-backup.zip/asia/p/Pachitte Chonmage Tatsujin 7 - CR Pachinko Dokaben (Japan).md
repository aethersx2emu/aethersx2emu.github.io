---
type : game
title : Pachitte Chonmage Tatsujin 7 - CR Pachinko Dokaben (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachitte%20Chonmage%20Tatsujin%207%20-%20CR%20Pachinko%20Dokaben%20%28Japan%29.7z
size : 522MB
---
