---
type : game
title : Plus Plum 2 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Plus%20Plum%202%20%28Japan%29.7z
size : 129MB
---
