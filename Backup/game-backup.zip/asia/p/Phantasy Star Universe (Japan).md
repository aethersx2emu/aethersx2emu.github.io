---
type : game
title : Phantasy Star Universe (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Phantasy%20Star%20Universe%20%28Japan%29.7z
size : 3.1GB
---
