---
type : game
title : Pachi-Slot Kanzen Kouryaku - Gigazone - The Meteor Strike (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Pachi-Slot%20Kanzen%20Kouryaku%20-%20Gigazone%20-%20The%20Meteor%20Strike%20%28Japan%29.7z
size : 103MB
---
