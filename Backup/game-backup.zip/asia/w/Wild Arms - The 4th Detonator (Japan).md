---
type : game
title : Wild Arms - The 4th Detonator (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wild%20Arms%20-%20The%204th%20Detonator%20%28Japan%29.7z
size : 2.4GB
---
