---
type : game
title : World Soccer Winning Eleven 8 - Asia Championship (China)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/World%20Soccer%20Winning%20Eleven%208%20-%20Asia%20Championship%20%28China%29.7z
size : 732MB
---
