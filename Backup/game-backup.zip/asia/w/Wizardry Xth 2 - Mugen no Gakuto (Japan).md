---
type : game
title : Wizardry Xth 2 - Mugen no Gakuto (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wizardry%20Xth%202%20-%20Mugen%20no%20Gakuto%20%28Japan%29.7z
size : 133MB
---
