---
type : game
title : WTA Tour Tennis (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/WTA%20Tour%20Tennis%20%28Japan%29.7z
size : 65MB
---
