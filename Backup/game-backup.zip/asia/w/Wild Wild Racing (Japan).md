---
type : game
title : Wild Wild Racing (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wild%20Wild%20Racing%20%28Japan%29.7z
size : 317MB
---
