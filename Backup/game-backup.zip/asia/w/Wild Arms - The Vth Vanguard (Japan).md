---
type : game
title : Wild Arms - The Vth Vanguard (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wild%20Arms%20-%20The%20Vth%20Vanguard%20%28Japan%29.7z
size : 1.8GB
---
