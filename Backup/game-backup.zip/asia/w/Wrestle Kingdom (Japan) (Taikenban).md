---
type : game
title : Wrestle Kingdom (Japan) (Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wrestle%20Kingdom%20%28Japan%29%20%28Taikenban%29.7z
size : 327MB
---
