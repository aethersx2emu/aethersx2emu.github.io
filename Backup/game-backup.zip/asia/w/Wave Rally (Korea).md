---
type : game
title : Wave Rally (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wave%20Rally%20%28Korea%29.7z
size : 536MB
---
