---
type : game
title : Wild Arms - The Vth Vanguard (Japan) (Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wild%20Arms%20-%20The%20Vth%20Vanguard%20%28Japan%29%20%28Taikenban%29.7z
size : 251MB
---
