---
type : game
title : WWE SmackDown! vs. Raw 2006 (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/WWE%20SmackDown%21%20vs.%20Raw%202006%20%28Korea%29.7z
size : 2.5GB
---
