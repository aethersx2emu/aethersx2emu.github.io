---
type : game
title : Wand of Fortune - Mirai e no Prologue (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wand%20of%20Fortune%20-%20Mirai%20e%20no%20Prologue%20%28Japan%29.7z
size : 1.2GB
---
