---
type : game
title : White Princess the Second - Yappari Ichizu ni Ittemo Soujanakutemo OK na Gotsugou Shugi Gakuen Ren'ai Adventure!! (Japan)
genre : 
region : asia
format : iso
link : https://archive.org/download/PS2-ASIA-ROMS321COM/White%20Princess%20the%20Second%20-%20Yappari%20Ichizu%20ni%20Ittemo%20Soujanakutemo%20OK%20na%20Gotsugou%20Shugi%20Gakuen%20Ren%27ai%20Adventure%21%21%20%28Japan%29.7z
size : 2.8GB
---
