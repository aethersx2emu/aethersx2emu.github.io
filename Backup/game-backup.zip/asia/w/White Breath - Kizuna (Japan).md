---
type : game
title : White Breath - Kizuna (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/White%20Breath%20-%20Kizuna%20%28Japan%29.7z
size : 1.7GB
---
