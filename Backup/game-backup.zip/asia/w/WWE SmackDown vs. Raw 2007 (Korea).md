---
type : game
title : WWE SmackDown vs. Raw 2007 (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/WWE%20SmackDown%20vs.%20Raw%202007%20%28Korea%29.7z
size : 3.0GB
---
