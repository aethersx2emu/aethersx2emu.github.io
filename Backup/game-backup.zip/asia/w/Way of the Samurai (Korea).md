---
type : game
title : Way of the Samurai (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Way%20of%20the%20Samurai%20%28Korea%29.7z
size : 478MB
---
