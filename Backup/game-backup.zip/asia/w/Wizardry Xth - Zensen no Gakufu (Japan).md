---
type : game
title : Wizardry Xth - Zensen no Gakufu (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wizardry%20Xth%20-%20Zensen%20no%20Gakufu%20%28Japan%29.7z
size : 223MB
---
