---
type : game
title : World Soccer Winning Eleven 10 (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/World%20Soccer%20Winning%20Eleven%2010%20%28Korea%29.7z
size : 1.3GB
---
