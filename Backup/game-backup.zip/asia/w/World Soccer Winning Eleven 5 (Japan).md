---
type : game
title : World Soccer Winning Eleven 5 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/World%20Soccer%20Winning%20Eleven%205%20%28Japan%29.7z
size : 288MB
---
