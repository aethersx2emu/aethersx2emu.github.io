---
type : game
title : World Soccer Winning Eleven 8 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/World%20Soccer%20Winning%20Eleven%208%20%28Japan%29.7z
size : 1.3GB
---
