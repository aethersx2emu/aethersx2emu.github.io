---
type : game
title : Warship Gunner 2 - Kurogane no Houkou (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Warship%20Gunner%202%20-%20Kurogane%20no%20Houkou%20%28Japan%29.7z
size : 1.3GB
---
