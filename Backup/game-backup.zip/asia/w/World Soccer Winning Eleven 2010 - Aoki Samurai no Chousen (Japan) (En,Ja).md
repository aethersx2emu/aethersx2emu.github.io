---
type : game
title : World Soccer Winning Eleven 2010 - Aoki Samurai no Chousen (Japan) (En,Ja)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/World%20Soccer%20Winning%20Eleven%202010%20-%20Aoki%20Samurai%20no%20Chousen%20%28Japan%29%20%28En%2CJa%29.7z
size : 1.8GB
---
