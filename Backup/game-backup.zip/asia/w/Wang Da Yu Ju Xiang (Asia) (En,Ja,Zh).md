---
type : game
title : Wang Da Yu Ju Xiang (Asia) (En,Ja,Zh)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wang%20Da%20Yu%20Ju%20Xiang%20%28Asia%29%20%28En%2CJa%2CZh%29.7z
size : 707MB
---
