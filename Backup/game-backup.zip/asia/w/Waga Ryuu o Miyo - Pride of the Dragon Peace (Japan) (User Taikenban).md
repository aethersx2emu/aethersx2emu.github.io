---
type : game
title : Waga Ryuu o Miyo - Pride of the Dragon Peace (Japan) (User Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Waga%20Ryuu%20o%20Miyo%20-%20Pride%20of%20the%20Dragon%20Peace%20%28Japan%29%20%28User%20Taikenban%29.7z
size : 839MB
---
