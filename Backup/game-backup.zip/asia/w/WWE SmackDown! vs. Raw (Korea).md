---
type : game
title : WWE SmackDown! vs. Raw (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/WWE%20SmackDown%21%20vs.%20Raw%20%28Korea%29.7z
size : 2.2GB
---
