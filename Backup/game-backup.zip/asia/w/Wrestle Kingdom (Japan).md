---
type : game
title : Wrestle Kingdom (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wrestle%20Kingdom%20%28Japan%29.7z
size : 1.7GB
---
