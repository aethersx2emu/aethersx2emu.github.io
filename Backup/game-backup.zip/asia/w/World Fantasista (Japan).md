---
type : game
title : World Fantasista (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/World%20Fantasista%20%28Japan%29.7z
size : 278MB
---
