---
type : game
title : WWE SmackDown! Shut Your Mouth (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/WWE%20SmackDown%21%20Shut%20Your%20Mouth%20%28Korea%29.7z
size : 1.9GB
---
