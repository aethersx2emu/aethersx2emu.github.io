---
type : game
title : Wand of Fortune (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Wand%20of%20Fortune%20%28Japan%29.7z
size : 2.6GB
---
