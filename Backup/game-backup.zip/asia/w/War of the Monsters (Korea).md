---
type : game
title : War of the Monsters (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/War%20of%20the%20Monsters%20%28Korea%29.7z
size : 869MB
---
