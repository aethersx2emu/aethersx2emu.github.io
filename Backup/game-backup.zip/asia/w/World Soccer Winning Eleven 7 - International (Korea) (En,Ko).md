---
type : game
title : World Soccer Winning Eleven 7 - International (Korea) (En,Ko)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/World%20Soccer%20Winning%20Eleven%207%20-%20International%20%28Korea%29%20%28En%2CKo%29.7z
size : 529MB
---
