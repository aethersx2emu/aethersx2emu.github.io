---
type : game
title : Jikkyou Powerful Pro Yakyuu 10 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jikkyou%20Powerful%20Pro%20Yakyuu%2010%20%28Japan%29.7z
size : 913MB
---
