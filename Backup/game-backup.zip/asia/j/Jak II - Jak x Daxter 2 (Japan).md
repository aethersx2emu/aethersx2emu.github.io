---
type : game
title : Jak II - Jak x Daxter 2 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jak%20II%20-%20Jak%20x%20Daxter%202%20%28Japan%29.7z
size : 2.6GB
---
