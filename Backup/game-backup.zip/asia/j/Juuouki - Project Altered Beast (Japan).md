---
type : game
title : Juuouki - Project Altered Beast (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Juuouki%20-%20Project%20Altered%20Beast%20%28Japan%29.7z
size : 1.6GB
---
