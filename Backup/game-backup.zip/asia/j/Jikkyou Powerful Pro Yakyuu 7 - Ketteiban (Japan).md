---
type : game
title : Jikkyou Powerful Pro Yakyuu 7 - Ketteiban (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jikkyou%20Powerful%20Pro%20Yakyuu%207%20-%20Ketteiban%20%28Japan%29.7z
size : 301MB
---
