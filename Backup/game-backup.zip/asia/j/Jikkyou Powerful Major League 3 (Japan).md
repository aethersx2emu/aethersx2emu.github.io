---
type : game
title : Jikkyou Powerful Major League 3 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jikkyou%20Powerful%20Major%20League%203%20%28Japan%29.7z
size : 991MB
---
