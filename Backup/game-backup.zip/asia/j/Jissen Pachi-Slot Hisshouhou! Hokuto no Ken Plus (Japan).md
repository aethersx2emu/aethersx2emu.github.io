---
type : game
title : Jissen Pachi-Slot Hisshouhou! Hokuto no Ken Plus (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachi-Slot%20Hisshouhou%21%20Hokuto%20no%20Ken%20Plus%20%28Japan%29.7z
size : 161MB
---
