---
type : game
title : Jissen Pachi-Slot Hisshouhou! Hokuto no Ken Special Edition (Japan) (Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachi-Slot%20Hisshouhou%21%20Hokuto%20no%20Ken%20Special%20Edition%20%28Japan%29%20%28Taikenban%29.7z
size : 44MB
---
