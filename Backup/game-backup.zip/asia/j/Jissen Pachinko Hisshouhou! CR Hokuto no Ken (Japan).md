---
type : game
title : Jissen Pachinko Hisshouhou! CR Hokuto no Ken (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachinko%20Hisshouhou%21%20CR%20Hokuto%20no%20Ken%20%28Japan%29.7z
size : 1.3GB
---
