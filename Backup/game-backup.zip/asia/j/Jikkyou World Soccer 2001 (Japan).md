---
type : game
title : Jikkyou World Soccer 2001 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jikkyou%20World%20Soccer%202001%20%28Japan%29.7z
size : 479MB
---
