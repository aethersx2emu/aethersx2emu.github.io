---
type : game
title : Jissen Pachi-Slot Hisshouhou! Juuou (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachi-Slot%20Hisshouhou%21%20Juuou%20%28Japan%29.7z
size : 12MB
---
