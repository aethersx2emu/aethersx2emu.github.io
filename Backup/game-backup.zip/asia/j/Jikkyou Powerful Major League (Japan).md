---
type : game
title : Jikkyou Powerful Major League (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jikkyou%20Powerful%20Major%20League%20%28Japan%29.7z
size : 818MB
---
