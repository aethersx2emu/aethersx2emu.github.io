---
type : game
title : Jissen Pachi-Slot Hisshouhou! Hokuto no Ken 2 - Ransei Haouden - Tenha no Shou (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachi-Slot%20Hisshouhou%21%20Hokuto%20no%20Ken%202%20-%20Ransei%20Haouden%20-%20Tenha%20no%20Shou%20%28Japan%29.7z
size : 2.3GB
---
