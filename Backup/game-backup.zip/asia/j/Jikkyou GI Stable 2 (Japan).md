---
type : game
title : Jikkyou GI Stable 2 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jikkyou%20GI%20Stable%202%20%28Japan%29.7z
size : 316MB
---
