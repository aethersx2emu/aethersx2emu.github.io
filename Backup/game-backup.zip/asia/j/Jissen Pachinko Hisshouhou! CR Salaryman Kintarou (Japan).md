---
type : game
title : Jissen Pachinko Hisshouhou! CR Salaryman Kintarou (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachinko%20Hisshouhou%21%20CR%20Salaryman%20Kintarou%20%28Japan%29.7z
size : 1.2GB
---
