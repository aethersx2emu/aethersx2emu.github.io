---
type : game
title : Jikkyou World Soccer 2000 - Final Edition (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jikkyou%20World%20Soccer%202000%20-%20Final%20Edition%20%28Japan%29.7z
size : 530MB
---
