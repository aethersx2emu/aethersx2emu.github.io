---
type : game
title : Jissen Pachi-Slot Hisshouhou! Juuou (Japan) (DX Pack)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachi-Slot%20Hisshouhou%21%20Juuou%20%28Japan%29%20%28DX%20Pack%29.7z
size : 12MB
---
