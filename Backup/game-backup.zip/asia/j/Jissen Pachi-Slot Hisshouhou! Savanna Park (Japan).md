---
type : game
title : Jissen Pachi-Slot Hisshouhou! Savanna Park (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachi-Slot%20Hisshouhou%21%20Savanna%20Park%20%28Japan%29.7z
size : 155MB
---
