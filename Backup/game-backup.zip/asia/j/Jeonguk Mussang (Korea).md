---
type : game
title : Jeonguk Mussang (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jeonguk%20Mussang%20%28Korea%29.7z
size : 1.8GB
---
