---
type : game
title : Jojo no Kimyou na Bouken - Phantom Blood (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jojo%20no%20Kimyou%20na%20Bouken%20-%20Phantom%20Blood%20%28Japan%29.7z
size : 592MB
---
