---
type : game
title : Jojo no Kimyou na Bouken - Ougon no Kaze (Japan) (Taikenban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jojo%20no%20Kimyou%20na%20Bouken%20-%20Ougon%20no%20Kaze%20%28Japan%29%20%28Taikenban%29.7z
size : 3.0GB
---
