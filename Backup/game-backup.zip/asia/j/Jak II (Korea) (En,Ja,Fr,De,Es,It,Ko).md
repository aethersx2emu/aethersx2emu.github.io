---
type : game
title : Jak II (Korea) (En,Ja,Fr,De,Es,It,Ko)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jak%20II%20%28Korea%29%20%28En%2CJa%2CFr%2CDe%2CEs%2CIt%2CKo%29.7z
size : 2.6GB
---
