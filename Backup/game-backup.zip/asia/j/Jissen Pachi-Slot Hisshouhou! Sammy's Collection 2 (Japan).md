---
type : game
title : Jissen Pachi-Slot Hisshouhou! Sammy's Collection 2 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachi-Slot%20Hisshouhou%21%20Sammy%27s%20Collection%202%20%28Japan%29.7z
size : 214MB
---
