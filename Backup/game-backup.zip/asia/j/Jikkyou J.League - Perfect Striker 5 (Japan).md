---
type : game
title : Jikkyou J.League - Perfect Striker 5 (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jikkyou%20J.League%20-%20Perfect%20Striker%205%20%28Japan%29.7z
size : 344MB
---
