---
type : game
title : Jissen Pachi-Slot Hisshouhou! Ultraman Club ST (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachi-Slot%20Hisshouhou%21%20Ultraman%20Club%20ST%20%28Japan%29.7z
size : 72MB
---
