---
type : game
title : Juunikoku-ki - Guren no Shirube Koujin no Michi (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Juunikoku-ki%20-%20Guren%20no%20Shirube%20Koujin%20no%20Michi%20%28Japan%29.7z
size : 634MB
---
