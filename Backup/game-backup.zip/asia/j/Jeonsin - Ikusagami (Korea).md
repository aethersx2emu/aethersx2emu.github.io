---
type : game
title : Jeonsin - Ikusagami (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jeonsin%20-%20Ikusagami%20%28Korea%29.7z
size : 2.1GB
---
