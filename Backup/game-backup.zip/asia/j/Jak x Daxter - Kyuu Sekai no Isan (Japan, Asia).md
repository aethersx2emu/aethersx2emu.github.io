---
type : game
title : Jak x Daxter - Kyuu Sekai no Isan (Japan, Asia)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jak%20x%20Daxter%20-%20Kyuu%20Sekai%20no%20Isan%20%28Japan%2C%20Asia%29.7z
size : 773MB
---
