---
type : game
title : Jissen Pachi-Slot Hisshouhou! Aladdin A (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachi-Slot%20Hisshouhou%21%20Aladdin%20A%20%28Japan%29.7z
size : 72MB
---
