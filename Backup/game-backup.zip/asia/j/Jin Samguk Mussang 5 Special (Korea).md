---
type : game
title : Jin Samguk Mussang 5 Special (Korea)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jin%20Samguk%20Mussang%205%20Special%20%28Korea%29.7z
size : 6.5GB
---
