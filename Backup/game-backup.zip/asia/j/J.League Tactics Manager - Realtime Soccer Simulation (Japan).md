---
type : game
title : J.League Tactics Manager - Realtime Soccer Simulation (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/J.League%20Tactics%20Manager%20-%20Realtime%20Soccer%20Simulation%20%28Japan%29.7z
size : 225MB
---
