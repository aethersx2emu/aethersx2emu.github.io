---
type : game
title : Jissen Pachi-Slot Hisshouhou! Selection - Salaryman Kintarou - Slotter Kintarou - Ore no Sora (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachi-Slot%20Hisshouhou%21%20Selection%20-%20Salaryman%20Kintarou%20-%20Slotter%20Kintarou%20-%20Ore%20no%20Sora%20%28Japan%29.7z
size : 414MB
---
