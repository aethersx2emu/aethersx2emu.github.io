---
type : game
title : Jewels Ocean - Star of Sierra Leone (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jewels%20Ocean%20-%20Star%20of%20Sierra%20Leone%20%28Japan%29.7z
size : 1.6GB
---
