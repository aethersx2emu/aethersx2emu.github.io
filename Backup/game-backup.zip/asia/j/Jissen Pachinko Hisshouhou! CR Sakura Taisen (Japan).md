---
type : game
title : Jissen Pachinko Hisshouhou! CR Sakura Taisen (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Jissen%20Pachinko%20Hisshouhou%21%20CR%20Sakura%20Taisen%20%28Japan%29.7z
size : 1.8GB
---
