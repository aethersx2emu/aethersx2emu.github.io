---
type : game
title : Orange Pocket - Root (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Orange%20Pocket%20-%20Root%20%28Japan%29.7z
size : 947MB
---
