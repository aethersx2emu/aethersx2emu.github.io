---
type : game
title : Ouran Koukou Host Club (Japan) (Genteiban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Ouran%20Koukou%20Host%20Club%20%28Japan%29%20%28Genteiban%29.7z
size : 1.5GB
---
