---
type : game
title : Omoi no Kakera - Close to (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Omoi%20no%20Kakera%20-%20Close%20to%20%28Japan%29.7z
size : 1.6GB
---
