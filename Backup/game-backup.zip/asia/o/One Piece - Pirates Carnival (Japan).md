---
type : game
title : One Piece - Pirates Carnival (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/One%20Piece%20-%20Pirates%20Carnival%20%28Japan%29.7z
size : 1.5GB
---
