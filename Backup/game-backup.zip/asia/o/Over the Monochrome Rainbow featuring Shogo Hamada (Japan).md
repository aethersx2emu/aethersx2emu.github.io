---
type : game
title : Over the Monochrome Rainbow featuring Shogo Hamada (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Over%20the%20Monochrome%20Rainbow%20featuring%20Shogo%20Hamada%20%28Japan%29.7z
size : 3.6GB
---
