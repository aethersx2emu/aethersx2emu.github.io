---
type : game
title : Onmyou Taisenki - Hasha no In (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Onmyou%20Taisenki%20-%20Hasha%20no%20In%20%28Japan%29.7z
size : 585MB
---
