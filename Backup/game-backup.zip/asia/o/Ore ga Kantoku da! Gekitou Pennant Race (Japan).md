---
type : game
title : Ore ga Kantoku da! Gekitou Pennant Race (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Ore%20ga%20Kantoku%20da%21%20Gekitou%20Pennant%20Race%20%28Japan%29.7z
size : 911MB
---
