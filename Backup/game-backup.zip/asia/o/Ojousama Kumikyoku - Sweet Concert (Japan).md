---
type : game
title : Ojousama Kumikyoku - Sweet Concert (Japan)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Ojousama%20Kumikyoku%20-%20Sweet%20Concert%20%28Japan%29.7z
size : 1.0GB
---
