---
type : game
title : One Piece - Pirates Carnival (Japan) (Multi Tap (SCPH-70120) Doukonban)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/One%20Piece%20-%20Pirates%20Carnival%20%28Japan%29%20%28Multi%20Tap%20%28SCPH-70120%29%20Doukonban%29.7z
size : 1.5GB
---
