---
type : game
title : Otostaz (Japan) (En,Ja)
genre : 
format : iso
region : asia
link : https://archive.org/download/PS2-ASIA-ROMS321COM/Otostaz%20%28Japan%29%20%28En%2CJa%29.7z
size : 512MB
---
